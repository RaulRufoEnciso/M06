function cambia(){
    let elemento = document.getElementById("input").value;
    document.getElementById("cuadrado").style.backgroundColor= elemento;
}